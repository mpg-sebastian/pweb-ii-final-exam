import React from 'react';
import HomeComponent from '../../components/home/Home';

function Home() {
  return <HomeComponent />
}

export default Home