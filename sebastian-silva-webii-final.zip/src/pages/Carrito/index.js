import React from 'react';
import CarritoComponent from '../../components/carrito/Carrito';

function Carrito() {
  return (
    <CarritoComponent />
  )
}

export default Carrito