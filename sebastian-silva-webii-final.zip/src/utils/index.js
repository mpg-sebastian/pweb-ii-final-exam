export const ApiWebURL = "https://servicios.campus.pe/servicioproductostodos.php";
export const ApiWebImagesURL = "https://servicios.campus.pe/";